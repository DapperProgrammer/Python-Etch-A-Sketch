from turtle import Turtle, Screen
timmy = Turtle()
screen = Screen()

def forward():

    timmy.forward(10)

def backward():

    timmy.backward(10)

def turn_right():

    timmy.right(10)

def turn_left():

    timmy.left(10)

def reset():

    timmy.clear()
    timmy.penup()
    timmy.home()
    timmy.pendown()


def main():

    # Tell the program to start listening
    screen.listen()

    # Event listener conditions.
    # Tells program what to listen for and what func to call when key is pressed.
    # Putting a parens() after a func name tells the program to call the func at that point and time.
    # As such, do not put parens() after the func names here. We only want that function called when the key is pressed.

    # These args are passed in using "keyword" arguments using the specified keys that func expects
    # VS just simply passing in " fowrard, "w" ". This allows for better readability.
    screen.onkey(fun = forward, key = "w")
    screen.onkey(fun = backward, key = "s")
    screen.onkey(fun = turn_right, key = "d")
    screen.onkey(fun = turn_left, key = "a")
    screen.onkey(fun= reset, key="c")

    # Tell program to not exit screen until exit btn is clicked
    screen.exitonclick()

main()